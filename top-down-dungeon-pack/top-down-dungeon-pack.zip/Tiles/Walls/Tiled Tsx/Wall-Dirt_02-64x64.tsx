<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Wall - Dirt 1 64x64" tilewidth="64" tileheight="64" tilecount="48" columns="8">
 <image source="../Wall-Dirt_02-64x64.png" trans="ff00ff" width="512" height="384"/>
 <wangsets>
  <wangset name="Dirt Wall 2" type="mixed" tile="30">
   <wangcolor name="Dirt Wall 2" color="#ff0000" tile="30" probability="1"/>
   <wangtile tileid="0" wangid="0,0,1,0,1,0,0,0"/>
   <wangtile tileid="1" wangid="0,0,0,0,1,0,1,0"/>
   <wangtile tileid="2" wangid="1,0,0,0,1,0,0,0"/>
   <wangtile tileid="3" wangid="0,0,1,0,1,0,1,0"/>
   <wangtile tileid="4" wangid="1,0,1,0,0,0,1,0"/>
   <wangtile tileid="5" wangid="0,0,0,0,0,0,1,0"/>
   <wangtile tileid="6" wangid="1,0,0,0,0,0,0,0"/>
   <wangtile tileid="7" wangid="1,0,1,0,1,0,1,0"/>
   <wangtile tileid="8" wangid="1,0,1,0,0,0,0,0"/>
   <wangtile tileid="9" wangid="1,0,0,0,0,0,1,0"/>
   <wangtile tileid="10" wangid="0,0,1,0,0,0,1,0"/>
   <wangtile tileid="11" wangid="1,0,1,0,1,0,0,0"/>
   <wangtile tileid="12" wangid="1,0,0,0,1,0,1,0"/>
   <wangtile tileid="13" wangid="0,0,0,0,1,0,0,0"/>
   <wangtile tileid="14" wangid="0,0,1,0,0,0,0,0"/>
   <wangtile tileid="15" wangid="0,0,1,1,1,0,0,0"/>
   <wangtile tileid="16" wangid="1,1,1,0,1,1,1,1"/>
   <wangtile tileid="17" wangid="1,1,1,1,1,0,1,1"/>
   <wangtile tileid="18" wangid="1,1,1,0,1,0,1,1"/>
   <wangtile tileid="19" wangid="1,0,1,1,1,1,1,0"/>
   <wangtile tileid="20" wangid="1,1,1,1,1,0,0,0"/>
   <wangtile tileid="21" wangid="1,0,0,0,1,1,1,1"/>
   <wangtile tileid="22" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="23" wangid="1,1,1,0,0,0,0,0"/>
   <wangtile tileid="24" wangid="1,0,1,1,1,1,1,1"/>
   <wangtile tileid="25" wangid="1,1,1,1,1,1,1,0"/>
   <wangtile tileid="26" wangid="1,0,1,0,1,1,1,1"/>
   <wangtile tileid="27" wangid="1,1,1,1,1,0,1,0"/>
   <wangtile tileid="28" wangid="0,0,1,1,1,1,1,0"/>
   <wangtile tileid="29" wangid="1,1,1,0,0,0,1,1"/>
   <wangtile tileid="31" wangid="0,0,0,0,1,1,1,0"/>
   <wangtile tileid="32" wangid="1,0,1,1,1,0,1,0"/>
   <wangtile tileid="33" wangid="1,0,1,0,1,1,1,0"/>
   <wangtile tileid="34" wangid="1,0,1,1,1,0,0,0"/>
   <wangtile tileid="35" wangid="1,0,0,0,1,1,1,0"/>
   <wangtile tileid="36" wangid="0,0,1,1,1,0,1,0"/>
   <wangtile tileid="37" wangid="0,0,1,0,1,1,1,0"/>
   <wangtile tileid="38" wangid="1,1,1,0,1,1,1,0"/>
   <wangtile tileid="39" wangid="1,0,0,0,0,0,1,1"/>
   <wangtile tileid="40" wangid="1,1,1,0,1,0,1,0"/>
   <wangtile tileid="41" wangid="1,0,1,0,1,0,1,1"/>
   <wangtile tileid="42" wangid="1,1,1,0,1,0,0,0"/>
   <wangtile tileid="43" wangid="1,0,0,0,1,0,1,1"/>
   <wangtile tileid="44" wangid="1,1,1,0,0,0,1,0"/>
   <wangtile tileid="45" wangid="1,0,1,0,0,0,1,1"/>
   <wangtile tileid="46" wangid="1,0,1,1,1,0,1,0"/>
  </wangset>
 </wangsets>
</tileset>
